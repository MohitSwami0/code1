const NutritionData = [
    {
        img: './miami-oasis/price-images/nutrition-images/nutrition-image1.jpg',
        title: 'Стандарт',
        price: 5999
    },
    {
        img: './miami-oasis/price-images/nutrition-images/nutrition-image2.jpg',
        title: 'Ресторан',
        price: 12999
    },
    {
        img: './miami-oasis/price-images/nutrition-images/nutrition-image3.jpg',
        title: 'Романтический ужин',
        price: 15999
    },
]

export default NutritionData