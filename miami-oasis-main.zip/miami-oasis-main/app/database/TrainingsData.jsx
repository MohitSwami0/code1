const TrainingsData = [
    {
        img: './miami-oasis/price-images/sports-images/sport-image1.jpg',
        title: 'Серфинг',
        price: 5999
    },
    {
        img: './miami-oasis/price-images/sports-images/sport-image2.jpg',
        title: 'Баскетбол',
        price: 4999
    },
    {
        img: './miami-oasis/price-images/sports-images/sport-image3.jpg',
        title: 'Кайтсерфинг',
        price: 5999
    },
    {
        img: './miami-oasis/price-images/sports-images/sport-image4.jpg',
        title: 'Посещения спорт. зала',
        price: 3999
    },
    {
        img: './miami-oasis/price-images/sports-images/sport-image5.jpg',
        title: 'Занятия гольфом',
        price: 8999
    },
]

export default TrainingsData